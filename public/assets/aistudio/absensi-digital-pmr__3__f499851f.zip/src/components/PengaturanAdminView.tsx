import React, { useState } from 'react';
import { KeyRound, Shield, CheckCircle2, AlertCircle } from 'lucide-react';
import { getMakassarDateTime } from '../utils/timezone.js';

interface PengaturanAdminViewProps {
  token: string;
  adminUsername: string;
  onUpdateAdmin: (newUsername: string, newToken: string) => void;
}

export const PengaturanAdminView: React.FC<PengaturanAdminViewProps> = ({
  token,
  adminUsername,
  onUpdateAdmin,
}) => {
  const [username, setUsername] = useState(adminUsername);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const currentMakassar = getMakassarDateTime();

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!currentPassword) {
      setErrorMsg('Password saat ini wajib diisi untuk verifikasi keamanan.');
      return;
    }

    if (newPassword && newPassword !== confirmPassword) {
      setErrorMsg('Konfirmasi password baru tidak cocok.');
      return;
    }

    if (newPassword && newPassword.length < 5) {
      setErrorMsg('Password baru minimal 5 karakter.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/admin/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          current_password: currentPassword,
          new_username: username,
          new_password: newPassword || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Gagal memperbarui profil admin.');
      }

      setSuccessMsg('Profil dan keamanan admin berhasil diperbarui.');
      onUpdateAdmin(data.admin.username, data.token);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Terjadi kesalahan sistem.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#343630] tracking-tight flex items-center gap-2">
          <span>Pengaturan Akun Sekretariat</span>
        </h2>
        <p className="text-xs sm:text-sm font-editorial italic text-[#85847D] mt-0.5">
          Kelola kredensial akses sekretaris dan preferensi keamanan sistem.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 bg-[#FFFDF8] border border-[#A5B19B] text-[#77846B] rounded-xl text-xs sm:text-sm flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-[#77846B] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 bg-[#FFFDF8] border border-[#C99491] text-[#984B50] rounded-xl text-xs sm:text-sm flex items-center gap-2 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-[#984B50] shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="bg-[#FFFDF8] rounded-2xl border border-[#EAE3D7] p-6 sm:p-7 shadow-2xs">
        <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs sm:text-sm">
          <div>
            <label className="block font-medium text-[#343630] mb-1.5 font-sans">
              Nama Pengguna (Username)
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 min-h-[44px] bg-[#F8F6F0] border border-[#EAE3D7] rounded-xl text-base sm:text-sm text-[#343630] focus:ring-1 focus:ring-[#984B50] focus:outline-none"
            />
          </div>

          <div className="pt-2 border-t border-[#EAE3D7]">
            <span className="text-xs font-semibold text-[#343630] uppercase tracking-wider block mb-3 font-sans">
              Ganti Kata Sandi
            </span>

            <div className="space-y-3">
              <div>
                <label className="block font-medium text-[#343630] mb-1.5 font-sans">
                  Password Saat Ini <span className="text-[#984B50]">*</span>
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Masukkan password admin saat ini"
                  required
                  className="w-full px-3.5 py-2.5 min-h-[44px] bg-[#F8F6F0] border border-[#EAE3D7] rounded-xl text-base sm:text-sm text-[#343630] focus:ring-1 focus:ring-[#984B50] focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-medium text-[#343630] mb-1.5 font-sans">
                  Password Baru (Kosongkan jika tidak ingin mengganti)
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimal 5 karakter"
                  className="w-full px-3.5 py-2.5 min-h-[44px] bg-[#F8F6F0] border border-[#EAE3D7] rounded-xl text-base sm:text-sm text-[#343630] focus:ring-1 focus:ring-[#984B50] focus:outline-none"
                />
              </div>

              {newPassword && (
                <div>
                  <label className="block font-medium text-[#343630] mb-1.5 font-sans">
                    Konfirmasi Password Baru <span className="text-[#984B50]">*</span>
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Ketik ulang password baru"
                    required
                    className="w-full px-3.5 py-2.5 min-h-[44px] bg-[#F8F6F0] border border-[#EAE3D7] rounded-xl text-base sm:text-sm text-[#343630] focus:ring-1 focus:ring-[#984B50] focus:outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 flex justify-end">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 min-h-[44px] bg-[#984B50] hover:bg-[#853f44] text-[#FFFDF8] font-medium rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50 text-xs sm:text-sm"
            >
              <KeyRound className="w-4 h-4" />
              <span>{isLoading ? 'Menyimpan...' : 'Simpan Perubahan'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* System info plaque */}
      <div className="bg-[#FFFDF8] rounded-2xl border border-[#EAE3D7] p-5 text-xs text-[#85847D] space-y-2">
        <div className="flex items-center gap-2 font-serif font-bold text-[#343630]">
          <Shield className="w-4 h-4 text-[#77846B]" />
          <span>Informasi Sistem & Parameter Keamanan</span>
        </div>
        <p className="font-editorial italic">
          • <strong>Zona Waktu Terdaftar:</strong> Asia/Makassar (WITA, UTC+8) — {currentMakassar.formattedDateIndo} pukul {currentMakassar.waktu} WITA.
        </p>
        <p>
          • <strong>Autentikasi:</strong> Enkripsi sandi menggunakan standar Bcrypt Salted Hashing dan JSON Web Token (JWT) dengan masa aktif 12 jam.
        </p>
        <p>
          • <strong>Integritas Database:</strong> SQLite WAL mode dengan snapshot histori absensi independen dari siklus hidup data anggota.
        </p>
      </div>
    </div>
  );
};
